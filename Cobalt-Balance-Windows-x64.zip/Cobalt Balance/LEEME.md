# Cobalt Balance — v1.0

Contabilidad para pequeñas empresas de Puerto Rico, al estilo QuickBooks. **Offline primero**: todo se guarda en el equipo y funciona sin internet. **Online opcional**: cuando hay conexión, sincroniza con la nube (Supabase) para usar varios equipos/usuarios por empresa (modelo SaaS).

## Qué incluye

| Módulo | Detalle |
|---|---|
| Interfaz | Menú lateral con iconos, botón global "+ Nuevo" (factura, pago, gasto, cheque, transferencia, asiento, cliente, proveedor, producto), páginas de cliente y proveedor con historial y totales, cheque con forma de cheque |
| Marca blanca | Con una clave de licencia firmada, el programa se llama "<Cliente> Balance" y admite el logo del cliente (menú y facturas). Sin licencia es Cobalt Balance. Las claves se crean con `tools/generador-licencias.html` (privado) |
| Aprende (tutorial) | 9 lecciones interactivas para quien no sabe contabilidad: el asistente en pantalla explica cada concepto, señala dónde tocar, comprueba cada paso y hace preguntas. Se hace en un modo práctica con datos separados que nunca se sincronizan ni tocan los datos reales |
| Guía de uso | Manual paso a paso incluido (F1 o menú Ayuda), en `app/manual/` |
| Inicio | Ingresos, gastos, ganancia neta, por cobrar, vencido, efectivo, IVU por pagar, gráfica 6 meses |
| Facturas | Borrador → emitida → pagada / vencida / parcial / anulada; numeración automática; imprimir/PDF |
| IVU | 11.5% (10.5% estatal + 1% municipal), 4% B2B/profesional, 7% alimentos preparados, exento — por línea |
| Pagos | ATH Móvil, ACH, cheque, efectivo, tarjeta; pagos parciales; cuenta de depósito |
| Gastos | Por categoría (cuenta), proveedor, pagado con banco/tarjeta/caja |
| Cheques | Escribir cheques con numeración automática, monto en letras (español/inglés), impresión en papel preimpreso (carta, cheque arriba + 2 talonarios) con ajuste de posición, registro Emitido/Cobrado/Anulado, asiento automático |
| Banco en línea (Plaid) | Conectar banco o tarjeta (Plaid Hosted Link, se abre en el navegador; el programa nunca ve la contraseña del banco). Los movimientos llegan solos (webhook diario + botón Actualizar). "Por revisar": sugiere si coincide con algo de tus libros, si es el pago de una factura abierta o un gasto conocido (aprende la categoría por comercio); confirmas con un toque. "Traer del banco en línea" en la conciliación. Reconexión cuando el banco pide entrar otra vez |
| Conciliación bancaria y de tarjetas | Por cuenta (banco, caja o tarjeta de crédito) y fecha de estado; importa OFX/QFX/QBO o el CSV del banco (Fecha/Descripción/Monto o Débito/Crédito); pagos de tarjeta y transferencias entre cuentas, empareja solo por monto y fecha (cheques por número), añade lo que falte como gasto, pago de factura u otro depósito; se cierra cuando la diferencia es $0.00 y marca los cheques como cobrados |
| Nómina | Empleados (por hora o salario; semanal, bisemanal, quincenal o mensual), nóminas en borrador → aprobada → anulada, horas extra a tiempo y medio, bonos, deducciones fijas. Cálculo mixto: Seguro Social 6.2% hasta $184,500, Medicare 1.45% (+0.9% sobre $200,000), SINOT 0.3% empleado y patrono hasta $9,000, desempleo PR (tasa del patrono) + aportación especial 1% hasta $7,000 y FUTA 0.6% hasta $7,000 automáticos; retención de Hacienda por empleado (% o monto fijo, la fija el contador). Asientos automáticos, reporte "Nómina y retenciones". Tasas editables en Ajustes → Nómina |
| Talonarios | PDF con acumulado del año, protegido con los últimos 4 del Seguro Social; botón "Enviar talonarios por email" (función `enviar-talonarios` + Resend). Los emails se toman de la nube, no del equipo |
| Conector de IA (MCP) | Función `mcp` (Streamable HTTP). Cada empresa crea su enlace en Ajustes → Conector de IA y lo pega en Claude (Conectores → Añadir conector personalizado) u otro asistente MCP. Herramientas: resumen_nomina, listar_empleados, crear_o_actualizar_empleado, listar_nominas, ver_nomina, calcular_pago, preparar_nomina, ajustar_borrador, reporte_retenciones. Solo crea borradores: aprobar y enviar es siempre del empleador |
| Contabilidad | Plan de cuentas, doble partida automática, asientos manuales con validación, mayor por cuenta |
| Reportes | Estado de resultados, Balance general (con verificación de cuadre), Cuentas por cobrar por antigüedad, IVU estatal/municipal, Gastos por categoría; exportar CSV |
| Datos | Respaldo/restauración JSON, datos de ejemplo; en Windows, copia automática diaria (30 días) |

## Usar en Windows (sin instalar nada)

1. Descomprime `Cobalt-Balance-Windows-x64.zip`.
2. Abre `Cobalt Balance.exe`. (Como no está firmado aún, Windows SmartScreen puede advertir: *Más información → Ejecutar de todas formas*.)
3. Los datos quedan en `%APPDATA%\Cobalt Balance\cobalt-datos.json` (menú *Archivo → Abrir carpeta de datos*).

## Activar la sincronización en la nube

1. Crea un proyecto en Supabase (supabase.com).
2. En *SQL Editor*, pega y ejecuta `supabase/schema.sql`.
3. En *Project Settings → API* copia la **URL** y la **anon public key**.
4. En la app: *Ajustes → Sincronización en la nube* → pega URL y clave → *Crear cuenta* / *Entrar*.
5. Se crea la empresa en la nube y se suben los datos. Desde otro equipo, entra con el mismo usuario y baja todo.

Cómo funciona: cada registro tiene `updated_at`; los cambios pendientes se suben cada 30 s o al volver la conexión; se bajan los cambios nuevos de otros equipos. Conflictos: gana la versión más reciente (también se aplica en el servidor con un trigger). Cada empresa solo ve sus datos (Row Level Security).

## Activar el envío de talonarios y el conector de IA

Hace falta la nube activa (sección anterior) y la [CLI de Supabase](https://supabase.com/docs/guides/local-development/cli/getting-started).

1. **Base de datos.** Vuelve a ejecutar `supabase/schema.sql` en el *SQL Editor* (se puede correr varias veces; añade la tabla `api_tokens` y sus funciones).
2. **Email (Resend).** Crea una cuenta en resend.com, verifica tu dominio (por ejemplo `cobaltpr.studio`; Resend te da los registros DNS para ponerlos en Spaceship) y crea una API key.
3. **Secretos y funciones.** En la carpeta del proyecto:

```bash
supabase login
supabase link --project-ref TU_REF_DE_PROYECTO
supabase secrets set RESEND_API_KEY=re_xxxxx PAYSTUB_FROM_EMAIL=nomina@cobaltpr.studio
supabase functions deploy enviar-talonarios --no-verify-jwt
supabase functions deploy mcp --no-verify-jwt
```

`--no-verify-jwt` es necesario: `mcp` se autentica con el enlace de cada empresa y `enviar-talonarios` valida la sesión del usuario por su cuenta.

4. **Probar.** En el programa: Nóminas → aprobar una → *Enviar talonarios por email*. Para la IA: Ajustes → Conector de IA → *Crear enlace del conector* y pégalo en Claude.

Seguridad: el enlace del conector se guarda solo como huella SHA-256 y se puede revocar; el asistente no ve el Seguro Social (solo si existe); no puede aprobar ni enviar. Una nómina aprobada o anulada nunca vuelve a borrador aunque llegue un cambio tardío del asistente.

## Activar el banco en línea (Plaid)

1. **Base de datos.** Vuelve a ejecutar `supabase/schema.sql` (añade `bank_connections` y `bank_link_sessions`; las llaves del banco quedan cifradas y ningún usuario puede leerlas).
2. **Plaid.** Crea una cuenta en dashboard.plaid.com. Las cuentas nuevas de EE. UU. empiezan en el plan *Trial*: gratis, datos reales, hasta 10 conexiones. En *Developers → Keys* copia el `client_id` y el `secret` de **Production** (el Trial usa producción). Para probar sin banco real usa el `secret` de **Sandbox** y `PLAID_ENV=sandbox` (usuario `user_good`, contraseña `pass_good`).
3. **Secretos y funciones:**

```bash
supabase secrets set PLAID_CLIENT_ID=xxxx PLAID_SECRET=xxxx PLAID_ENV=production BANK_TOKEN_KEY=$(openssl rand -base64 32)
supabase functions deploy banco --no-verify-jwt
supabase functions deploy banco-webhook --no-verify-jwt
```

Guarda `BANK_TOKEN_KEY` en un lugar seguro: si se pierde, hay que reconectar todos los bancos.

4. **Probar.** En el programa: *Banco en línea → Conectar banco*. Se abre Plaid en el navegador; al terminar, el programa trae las cuentas y los movimientos de los últimos 90 días.

Notas: solo se importan movimientos ya procesados (no pendientes). El webhook de Plaid avisa cuando hay movimientos nuevos; si llega un aviso falso, lo único que hace es volver a sincronizar. Pasar de Trial a un plan pagado es una solicitud en el panel de Plaid; después no se puede volver a Trial.

## Compilar el instalador (.exe con instalador) en Windows

```bash
npm install
npm start        # probar
npm run dist     # genera instalador NSIS + versión portable en /dist
```

## Estructura

```
app/index.html    Interfaz + motor contable + sincronización (un solo archivo, también corre como web)
app/main.js       Proceso de Electron: guardado en disco, respaldos, menú
app/preload.js    Puente seguro interfaz ↔ disco
app/payroll-core.js   Motor de cálculo de nómina (compartido con la función mcp)
app/vendor/       jsPDF (licencia MIT) para los talonarios
app/manual/       Guía de uso (HTML + capturas)
app/icon.ico      Icono de Cobalt Balance
tools/generador-licencias.html   Generador de licencias — NO distribuir (contiene la clave privada)
supabase/schema.sql   Tablas, seguridad por empresa, funciones create_org / add_member / create_api_token / revoke_api_token
supabase/functions/enviar-talonarios   Envía los talonarios por email (Resend)
supabase/functions/mcp                 Conector de IA (MCP)
supabase/functions/banco               Banco en línea: conectar, sincronizar, desconectar (Plaid)
supabase/functions/banco-webhook       Avisos de Plaid (movimientos nuevos, reconexión)
supabase/functions/_shared             Acceso a datos y copia de payroll-core.js
```

## Próximos pasos sugeridos para el producto SaaS

- Cobro de suscripciones (Stripe) usando la columna `orgs.plan` / `trial_ends`.
- Banco en línea: reglas editables, dividir un movimiento en varias categorías, adjuntar recibos.
- Envío de facturas por email y WhatsApp (tu API de WhatsApp Business), con enlace de pago.
- Cuentas por pagar (bills), inventario, 1099/480.6.
- Nómina: tablas de retención de Hacienda automáticas, formularios W-2/499R-2, 941-PR y 499R-1 listos para radicar, depósito directo (NACHA), seguro choferil.
- Roles en la interfaz (dueño, contador, solo lectura) — ya existen en la base de datos.
- Firma de código del .exe y auto-actualizaciones (electron-updater).
- Numeración de facturas a prueba de conflictos cuando dos equipos facturan offline al mismo tiempo.

> Las tasas de nómina vienen con los valores de 2026 (SSA, Ley 139 SINOT, desempleo PR, FUTA). La tasa de desempleo varía por patrono. Confirma todo con tu contador.
>
> Las tasas de IVU vienen configuradas según la guía general vigente (11.5% / 4% / 7%). Confirma con tu contador la clasificación correcta de cada producto o servicio.
