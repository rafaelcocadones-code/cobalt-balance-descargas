// Puente seguro entre la interfaz y el disco local
const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('desktop', {
  load: id => ipcRenderer.invoke('data:load', id),
  save: (content, id) => ipcRenderer.invoke('data:save', content, id),
  saveSync: (content, id) => ipcRenderer.sendSync('data:saveSync', content, id),
  loadIndex: () => ipcRenderer.invoke('co:index'),
  saveIndex: content => ipcRenderer.invoke('co:saveIndex', content),
  removeCompany: id => ipcRenderer.invoke('co:remove', id),
  openDataFolder: () => ipcRenderer.invoke('data:openFolder'),
});
