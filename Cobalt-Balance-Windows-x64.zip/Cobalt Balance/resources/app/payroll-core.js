/* Cobalt Balance — motor de nómina (Puerto Rico)
   Archivo compartido: lo usan el programa (navegador / Windows) y el conector de IA (Supabase Edge Function).
   No depende del DOM. Expone globalThis.PayrollCore.

   Cálculo "mixto":
   - Automático: Seguro Social, Medicare (+ adicional), SINOT empleado y patrono, desempleo PR + aportación especial, FUTA.
   - Por empleado (lo fija el contador): retención de contribución sobre ingresos de PR (% o monto fijo) y deducciones fijas.
   Las tasas por defecto son las de 2026 y se pueden cambiar en Ajustes → Nómina. */
(function (root) {
  'use strict';
  const r2 = n => Math.round((Number(n) || 0) * 100 + Number.EPSILON) / 100;
  const num = v => (v === null || v === undefined || v === '' || isNaN(Number(v))) ? null : Number(v);

  const FREQ = {
    weekly:      { label: 'Semanal',    per: 52, hours: 40 },
    biweekly:    { label: 'Bisemanal',  per: 26, hours: 80 },
    semimonthly: { label: 'Quincenal',  per: 24, hours: 86.67 },
    monthly:     { label: 'Mensual',    per: 12, hours: 173.33 },
  };

  // Tasas en porciento. Fuentes 2026: SSA (base $184,500), Ley 139 SINOT (0.3% sobre $9,000 c/u),
  // desempleo PR base $7,000 (tasa del patrono varía; 2.8% patrono nuevo), aportación especial 1% sobre $7,000, FUTA 0.6% sobre $7,000.
  const DEFAULTS = {
    year: 2026,
    ssRate: 6.2, ssWageBase: 184500,
    medRate: 1.45, addlMedRate: 0.9, addlMedThreshold: 200000,
    sinotRate: 0.3, sinotEmployerRate: 0.3, sinotWageBase: 9000,
    sutaRate: 2.8, sutaSpecialRate: 1.0, sutaWageBase: 7000,
    futaRate: 0.6, futaWageBase: 7000,
    otMultiplier: 1.5,
  };

  function config(settings) {
    const c = Object.assign({}, DEFAULTS);
    const p = (settings && settings.payroll) || {};
    for (const k in DEFAULTS) { const v = num(p[k]); if (v !== null) c[k] = v; }
    return c;
  }

  const LIVE = s => s === 'approved';

  /* Acumulados del año para un empleado, antes de la nómina indicada */
  function ytdBefore(employeeId, run, runs) {
    const y = String(run.payDate || '').slice(0, 4);
    const t = { gross: 0, ssWages: 0, sinotWages: 0, sutaWages: 0, futaWages: 0, ss: 0, medicare: 0, sinot: 0, prTax: 0, otherTotal: 0, net: 0, regularPay: 0, otPay: 0, bonus: 0, regularHours: 0, otHours: 0 };
    (runs || []).forEach(r => {
      if (!r || r.deleted || r.id === run.id || !LIVE(r.status)) return;
      if (String(r.payDate || '').slice(0, 4) !== y) return;
      const earlier = r.payDate < run.payDate || (r.payDate === run.payDate && String(r.createdAt || '') < String(run.createdAt || ''));
      if (!earlier) return;
      (r.lines || []).forEach(l => { if (l.employeeId === employeeId) for (const k in t) t[k] += Number(l[k]) || 0; });
    });
    for (const k in t) t[k] = r2(t[k]);
    return t;
  }

  function hourlyRateOf(emp) {
    const rate = Number(emp.rate) || 0;
    return emp.payType === 'hourly' ? rate : rate / 2080;
  }

  /* Calcula una línea (un empleado en una nómina) */
  function calcLine(emp, input, ytd, cfg) {
    input = input || {}; ytd = ytd || {}; cfg = cfg || DEFAULTS;
    const f = FREQ[emp.frequency] || FREQ.biweekly;
    const rate = Number(emp.rate) || 0;
    let regularHours, regularPay;
    if (emp.payType === 'hourly') {
      regularHours = num(input.hours) !== null ? Number(input.hours) : f.hours;
      regularPay = r2(regularHours * rate);
    } else {
      regularHours = num(input.hours) !== null ? Number(input.hours) : f.hours;
      regularPay = r2(rate / f.per);
    }
    const otHours = Math.max(0, num(input.otHours) || 0);
    const otPay = r2(otHours * hourlyRateOf(emp) * cfg.otMultiplier);
    const bonus = r2(Math.max(0, num(input.bonus) || 0));
    const gross = r2(regularPay + otPay + bonus);

    const fica = !emp.exemptFica;
    const ssWages = fica ? r2(Math.max(0, Math.min(gross, cfg.ssWageBase - (ytd.ssWages || 0)))) : 0;
    const ss = r2(ssWages * cfg.ssRate / 100);
    let medicare = 0;
    if (fica) {
      const prev = ytd.gross || 0, th = cfg.addlMedThreshold;
      const over = Math.max(0, prev + gross - th) - Math.max(0, prev - th);
      medicare = r2(gross * cfg.medRate / 100 + over * cfg.addlMedRate / 100);
    }
    const sinotOn = emp.sinot !== false;
    const sinotWages = sinotOn ? r2(Math.max(0, Math.min(gross, cfg.sinotWageBase - (ytd.sinotWages || 0)))) : 0;
    const sinot = r2(sinotWages * cfg.sinotRate / 100);

    let prTax;
    if (num(input.prTax) !== null) prTax = r2(input.prTax);
    else if (emp.prMode === 'percent') prTax = r2(gross * (Number(emp.prValue) || 0) / 100);
    else if (emp.prMode === 'fixed') prTax = r2(Math.min(Number(emp.prValue) || 0, gross));
    else prTax = 0;

    const deductions = (emp.deductions || [])
      .filter(d => d && Number(d.amount) > 0)
      .map(d => ({ name: String(d.name || 'Deducción').slice(0, 40), amount: r2(d.amount) }));
    if (Number(input.extraAmount) > 0) deductions.push({ name: String(input.extraName || 'Otra deducción').slice(0, 40), amount: r2(input.extraAmount) });
    const otherTotal = r2(deductions.reduce((s, d) => s + d.amount, 0));
    const taxes = r2(ss + medicare + sinot + prTax);
    const totalDeductions = r2(taxes + otherTotal);
    const net = r2(gross - totalDeductions);

    const sutaOn = emp.suta !== false;
    const sutaWages = sutaOn ? r2(Math.max(0, Math.min(gross, cfg.sutaWageBase - (ytd.sutaWages || 0)))) : 0;
    const futaWages = sutaOn ? r2(Math.max(0, Math.min(gross, cfg.futaWageBase - (ytd.futaWages || 0)))) : 0;
    const er = {
      ss: r2(ssWages * cfg.ssRate / 100),
      medicare: fica ? r2(gross * cfg.medRate / 100) : 0,
      sinot: r2(sinotWages * cfg.sinotEmployerRate / 100),
      suta: r2(sutaWages * cfg.sutaRate / 100),
      sutaSpecial: r2(sutaWages * cfg.sutaSpecialRate / 100),
      futa: r2(futaWages * cfg.futaRate / 100),
    };
    er.total = r2(er.ss + er.medicare + er.sinot + er.suta + er.sutaSpecial + er.futa);

    const warnings = [];
    if (net < 0) warnings.push('Neto negativo');
    if (!emp.email) warnings.push('Sin email');
    if (!/^\d{4}$/.test(String(emp.ssnLast4 || ''))) warnings.push('Sin últimos 4 del Seguro Social');
    if (!rate) warnings.push('Sin salario o tarifa');

    return {
      employeeId: emp.id, name: emp.name, position: emp.position || '',
      input: { hours: num(input.hours), otHours: num(input.otHours) || 0, bonus: num(input.bonus) || 0, prTax: num(input.prTax), extraName: input.extraName || '', extraAmount: num(input.extraAmount) || 0 },
      payType: emp.payType, rate, frequency: emp.frequency,
      regularHours: r2(regularHours), regularPay, otHours, otPay, bonus, gross,
      ssWages, ss, medicare, sinotWages, sinot, prTax,
      deductions, otherTotal, totalDeductions, net,
      sutaWages, futaWages, er, warnings,
    };
  }

  function blankInput(emp) {
    return { employeeId: emp.id, hours: emp.payType === 'hourly' ? (FREQ[emp.frequency] || FREQ.biweekly).hours : null, otHours: 0, bonus: 0, prTax: null, extraName: '', extraAmount: 0 };
  }

  /* Recalcula todas las líneas de una nómina en borrador */
  function computeRun(run, employees, runs, settings) {
    const cfg = config(settings);
    const byId = {}; (employees || []).forEach(e => { byId[e.id] = e; });
    const lines = (run.lines || []).map(l => {
      const emp = byId[l.employeeId];
      if (!emp) return l;
      const inp = Object.assign({ employeeId: l.employeeId }, l.input || l);
      return calcLine(emp, inp, ytdBefore(emp.id, run, runs), cfg);
    });
    return Object.assign({}, run, { lines, totals: totals(lines) });
  }

  function totals(lines) {
    const t = { employees: 0, gross: 0, ss: 0, medicare: 0, sinot: 0, prTax: 0, otherTotal: 0, totalDeductions: 0, net: 0, erSs: 0, erMedicare: 0, erSinot: 0, erSuta: 0, erSutaSpecial: 0, erFuta: 0, erTotal: 0 };
    (lines || []).forEach(l => {
      t.employees++;
      ['gross', 'ss', 'medicare', 'sinot', 'prTax', 'otherTotal', 'totalDeductions', 'net'].forEach(k => { t[k] += Number(l[k]) || 0; });
      const e = l.er || {};
      t.erSs += e.ss || 0; t.erMedicare += e.medicare || 0; t.erSinot += e.sinot || 0; t.erSuta += e.suta || 0; t.erSutaSpecial += e.sutaSpecial || 0; t.erFuta += e.futa || 0; t.erTotal += e.total || 0;
    });
    for (const k in t) if (k !== 'employees') t[k] = r2(t[k]);
    t.totalCost = r2(t.gross + t.erTotal);
    return t;
  }

  /* Totales de nóminas aprobadas en un rango de fechas de pago (para planillas 941, 499R-1, SINOT, desempleo) */
  function withholdingReport(runs, from, to) {
    const sel = (runs || []).filter(r => r && !r.deleted && LIVE(r.status) && (!from || r.payDate >= from) && (!to || r.payDate <= to));
    const all = []; sel.forEach(r => (r.lines || []).forEach(l => all.push(l)));
    const t = totals(all);
    t.runs = sel.length;
    t.ssWages = r2(all.reduce((s, l) => s + (l.ssWages || 0), 0));
    t.sinotWages = r2(all.reduce((s, l) => s + (l.sinotWages || 0), 0));
    t.sutaWages = r2(all.reduce((s, l) => s + (l.sutaWages || 0), 0));
    t.futaWages = r2(all.reduce((s, l) => s + (l.futaWages || 0), 0));
    t.fica941 = r2(t.ss + t.medicare + t.erSs + t.erMedicare);
    const byEmp = {};
    all.forEach(l => { const e = byEmp[l.employeeId] = byEmp[l.employeeId] || { employeeId: l.employeeId, name: l.name, gross: 0, ss: 0, medicare: 0, sinot: 0, prTax: 0, net: 0 }; ['gross', 'ss', 'medicare', 'sinot', 'prTax', 'net'].forEach(k => { e[k] = r2(e[k] + (l[k] || 0)); }); });
    t.byEmployee = Object.values(byEmp).sort((a, b) => String(a.name).localeCompare(String(b.name)));
    return t;
  }

  const api = { r2, FREQ, DEFAULTS, config, ytdBefore, calcLine, blankInput, computeRun, totals, withholdingReport, version: '1.0.0' };
  root.PayrollCore = api;
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
})(typeof globalThis !== 'undefined' ? globalThis : this);
