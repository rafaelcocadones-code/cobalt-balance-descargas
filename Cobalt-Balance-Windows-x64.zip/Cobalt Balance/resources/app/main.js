// Cobalt Balance — proceso principal de Electron (Windows)
const { app, BrowserWindow, ipcMain, shell, Menu } = require('electron');
const path = require('path');
const fs = require('fs');

const DATA_DIR = app.getPath('userData');
const DATA_FILE = path.join(DATA_DIR, 'cobalt-datos.json');
const BACKUP_DIR = path.join(DATA_DIR, 'respaldos');
const KEEP_BACKUPS = 30;

function ensureDirs() { fs.mkdirSync(BACKUP_DIR, { recursive: true }); }

// Cada empresa tiene su propio archivo. La primera ("main") usa el archivo de siempre.
const INDEX_FILE = path.join(DATA_DIR, 'cobalt-empresas.json');
const CO_DIR = path.join(DATA_DIR, 'empresas');
const validId = id => id === undefined || id === null || id === 'main' || /^[a-z0-9-]{4,40}$/.test(String(id));
const fileFor = id => (!id || id === 'main') ? DATA_FILE : path.join(CO_DIR, `${id}.json`);
const backupPrefix = id => (!id || id === 'main') ? 'cobalt-' : `empresa-${id}-`;

function writeFileAtomic(file, content) {
  fs.mkdirSync(path.dirname(file), { recursive: true });
  const tmp = file + '.tmp';
  fs.writeFileSync(tmp, content, 'utf8');
  fs.renameSync(tmp, file);
}
function writeAtomic(content, id) {
  if (!validId(id)) throw new Error('Empresa inválida');
  ensureDirs();
  const file = fileFor(id);
  writeFileAtomic(file, content);
  // Copia de seguridad diaria automática, por empresa
  const day = new Date().toISOString().slice(0, 10);
  const pre = backupPrefix(id);
  const daily = path.join(BACKUP_DIR, `${pre}${day}.json`);
  if (!fs.existsSync(daily)) {
    fs.copyFileSync(file, daily);
    const re = new RegExp('^' + pre.replace(/[-]/g, '\\-') + '\\d{4}-\\d{2}-\\d{2}\\.json$');
    const files = fs.readdirSync(BACKUP_DIR).filter(f => re.test(f)).sort();
    files.slice(0, Math.max(0, files.length - KEEP_BACKUPS)).forEach(f => fs.unlinkSync(path.join(BACKUP_DIR, f)));
  }
}

// Si existen datos de versiones anteriores ("Cobalt Books" o "Cobalt Contable"), se copian una sola vez
function migrateOldData() {
  try {
    if (fs.existsSync(DATA_FILE)) return;
    for (const name of ['Cobalt Books', 'Cobalt Contable']) {
      const old = path.join(app.getPath('appData'), name, 'cobalt-datos.json');
      if (fs.existsSync(old)) { ensureDirs(); fs.copyFileSync(old, DATA_FILE); return; }
    }
  } catch (e) { /* sin datos anteriores */ }
}
function openManual() {
  const w = new BrowserWindow({ width: 980, height: 820, title: 'Guía de Cobalt Balance', backgroundColor: '#ffffff', webPreferences: { contextIsolation: true, nodeIntegration: false, sandbox: true } });
  w.setMenuBarVisibility(false);
  w.loadFile(path.join(__dirname, 'manual', 'index.html'));
}
ipcMain.handle('data:load', (_e, id) => {
  if (!validId(id)) return null;
  if (!id || id === 'main') migrateOldData();
  try { return fs.readFileSync(fileFor(id), 'utf8'); } catch (e) { return null; }
});
ipcMain.handle('data:save', (_e, content, id) => { writeAtomic(content, id); return true; });
ipcMain.on('data:saveSync', (e, content, id) => { try { writeAtomic(content, id); e.returnValue = true; } catch (err) { e.returnValue = false; } });
ipcMain.handle('co:index', () => { try { return fs.readFileSync(INDEX_FILE, 'utf8'); } catch (e) { return null; } });
ipcMain.handle('co:saveIndex', (_e, content) => { ensureDirs(); writeFileAtomic(INDEX_FILE, content); return true; });
// Quitar una empresa de este equipo: el archivo se mueve a respaldos, nunca se borra
ipcMain.handle('co:remove', (_e, id) => {
  if (!id || id === 'main' || !validId(id)) return false;
  const f = fileFor(id); if (!fs.existsSync(f)) return true;
  ensureDirs(); fs.renameSync(f, path.join(BACKUP_DIR, `quitada-${id}-${Date.now()}.json`)); return true;
});
ipcMain.handle('data:openFolder', () => shell.openPath(DATA_DIR));

function createWindow() {
  const win = new BrowserWindow({
    width: 1320, height: 860, minWidth: 900, minHeight: 600,
    title: 'Cobalt Balance', backgroundColor: '#f4f6fb', show: false,
    icon: path.join(__dirname, 'icon.png'),
    webPreferences: { preload: path.join(__dirname, 'preload.js'), contextIsolation: true, nodeIntegration: false, sandbox: true },
  });
  win.loadFile(path.join(__dirname, 'index.html'));
  win.once('ready-to-show', () => win.show());
  // Enlaces externos se abren en el navegador
  win.webContents.setWindowOpenHandler(({ url }) => { if (/^https?:/.test(url)) shell.openExternal(url); else if (/\/manual\/index\.html/.test(url)) openManual(); return { action: 'deny' }; });
}

const isMac = process.platform === 'darwin';
const menu = Menu.buildFromTemplate([
  // En Mac el primer menú lleva el nombre del programa
  ...(isMac ? [{ label: 'Cobalt Balance', submenu: [
    { role: 'about', label: 'Acerca de Cobalt Balance' }, { type: 'separator' },
    { role: 'hide', label: 'Ocultar Cobalt Balance' }, { role: 'hideOthers', label: 'Ocultar otros' }, { role: 'unhide', label: 'Mostrar todo' }, { type: 'separator' },
    { role: 'quit', label: 'Salir de Cobalt Balance' },
  ]}] : []),
  { label: 'Archivo', submenu: [
    { label: 'Abrir carpeta de datos', click: () => shell.openPath(DATA_DIR) },
    { type: 'separator' },
    { label: 'Imprimir', accelerator: 'CmdOrCtrl+P', click: (_m, w) => w && w.webContents.print() },
    ...(isMac ? [{ type: 'separator' }, { role: 'close', label: 'Cerrar ventana' }] : [{ type: 'separator' }, { role: 'quit', label: 'Salir' }]),
  ]},
  { label: 'Editar', submenu: [
    { role: 'undo', label: 'Deshacer' }, { role: 'redo', label: 'Rehacer' }, { type: 'separator' },
    { role: 'cut', label: 'Cortar' }, { role: 'copy', label: 'Copiar' }, { role: 'paste', label: 'Pegar' }, { role: 'selectAll', label: 'Seleccionar todo' },
  ]},
  { label: 'Ver', submenu: [
    { role: 'reload', label: 'Recargar' }, { role: 'toggleDevTools', label: 'Herramientas de desarrollo' }, { type: 'separator' },
    { role: 'resetZoom', label: 'Tamaño normal' }, { role: 'zoomIn', label: 'Acercar' }, { role: 'zoomOut', label: 'Alejar' }, { type: 'separator' },
    { role: 'togglefullscreen', label: 'Pantalla completa' },
  ]},
  ...(isMac ? [{ role: 'windowMenu', label: 'Ventana' }] : []),
  { role: 'help', label: 'Ayuda', submenu: [{ label: 'Guía de uso', accelerator: 'F1', click: openManual }, { label: 'Cobalt Studio', click: () => shell.openExternal('https://cobaltpr.studio') }] },
]);

if (!app.requestSingleInstanceLock()) {
  app.quit();
} else {
  app.on('second-instance', () => { const w = BrowserWindow.getAllWindows()[0]; if (w) { if (w.isMinimized()) w.restore(); w.focus(); } });
  app.whenReady().then(() => {
    Menu.setApplicationMenu(menu);
    if (isMac) app.setAboutPanelOptions({ applicationName: 'Cobalt Balance', applicationVersion: app.getVersion(), copyright: '© 2026 Cobalt Studio LLC' });
    createWindow();
  });
  // En Mac, al tocar el icono del Dock sin ventanas abiertas, se vuelve a abrir
  app.on('activate', () => { if (!BrowserWindow.getAllWindows().length) createWindow(); });
  app.on('window-all-closed', () => app.quit());
}
